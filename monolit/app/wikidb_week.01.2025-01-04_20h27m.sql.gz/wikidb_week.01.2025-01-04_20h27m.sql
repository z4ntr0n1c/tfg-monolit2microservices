-- MySQL dump 10.13  Distrib 8.0.40, for Linux (x86_64)
--
-- Host: localhost    Database: wikidb
-- ------------------------------------------------------
-- Server version	8.0.40-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `wikidb`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `wikidb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `wikidb`;

--
-- Table structure for table `m2mactor`
--

DROP TABLE IF EXISTS `m2mactor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mactor` (
  `actor_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `actor_user` int unsigned DEFAULT NULL,
  `actor_name` varbinary(255) NOT NULL,
  PRIMARY KEY (`actor_id`),
  UNIQUE KEY `actor_name` (`actor_name`),
  UNIQUE KEY `actor_user` (`actor_user`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mactor`
--

LOCK TABLES `m2mactor` WRITE;
/*!40000 ALTER TABLE `m2mactor` DISABLE KEYS */;
INSERT INTO `m2mactor` VALUES (1,1,_binary 'Sergio'),(2,2,_binary 'MediaWiki default');
/*!40000 ALTER TABLE `m2mactor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2marchive`
--

DROP TABLE IF EXISTS `m2marchive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2marchive` (
  `ar_id` int unsigned NOT NULL AUTO_INCREMENT,
  `ar_namespace` int NOT NULL DEFAULT '0',
  `ar_title` varbinary(255) NOT NULL DEFAULT '',
  `ar_comment_id` bigint unsigned NOT NULL,
  `ar_actor` bigint unsigned NOT NULL,
  `ar_timestamp` binary(14) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ar_minor_edit` tinyint NOT NULL DEFAULT '0',
  `ar_rev_id` int unsigned NOT NULL,
  `ar_deleted` tinyint unsigned NOT NULL DEFAULT '0',
  `ar_len` int unsigned DEFAULT NULL,
  `ar_page_id` int unsigned DEFAULT NULL,
  `ar_parent_id` int unsigned DEFAULT NULL,
  `ar_sha1` varbinary(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`ar_id`),
  UNIQUE KEY `ar_revid_uniq` (`ar_rev_id`),
  KEY `name_title_timestamp` (`ar_namespace`,`ar_title`,`ar_timestamp`),
  KEY `ar_actor_timestamp` (`ar_actor`,`ar_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2marchive`
--

LOCK TABLES `m2marchive` WRITE;
/*!40000 ALTER TABLE `m2marchive` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2marchive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mbot_passwords`
--

DROP TABLE IF EXISTS `m2mbot_passwords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mbot_passwords` (
  `bp_user` int unsigned NOT NULL,
  `bp_app_id` varbinary(32) NOT NULL,
  `bp_password` tinyblob NOT NULL,
  `bp_token` binary(32) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `bp_restrictions` blob NOT NULL,
  `bp_grants` blob NOT NULL,
  PRIMARY KEY (`bp_user`,`bp_app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mbot_passwords`
--

LOCK TABLES `m2mbot_passwords` WRITE;
/*!40000 ALTER TABLE `m2mbot_passwords` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mbot_passwords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mcategory`
--

DROP TABLE IF EXISTS `m2mcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mcategory` (
  `cat_id` int unsigned NOT NULL AUTO_INCREMENT,
  `cat_title` varbinary(255) NOT NULL,
  `cat_pages` int NOT NULL DEFAULT '0',
  `cat_subcats` int NOT NULL DEFAULT '0',
  `cat_files` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`cat_id`),
  UNIQUE KEY `cat_title` (`cat_title`),
  KEY `cat_pages` (`cat_pages`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mcategory`
--

LOCK TABLES `m2mcategory` WRITE;
/*!40000 ALTER TABLE `m2mcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mcategorylinks`
--

DROP TABLE IF EXISTS `m2mcategorylinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mcategorylinks` (
  `cl_from` int unsigned NOT NULL DEFAULT '0',
  `cl_to` varbinary(255) NOT NULL DEFAULT '',
  `cl_sortkey` varbinary(230) NOT NULL DEFAULT '',
  `cl_sortkey_prefix` varbinary(255) NOT NULL DEFAULT '',
  `cl_timestamp` timestamp NOT NULL,
  `cl_collation` varbinary(32) NOT NULL DEFAULT '',
  `cl_type` enum('page','subcat','file') NOT NULL DEFAULT 'page',
  PRIMARY KEY (`cl_from`,`cl_to`),
  KEY `cl_sortkey` (`cl_to`,`cl_type`,`cl_sortkey`,`cl_from`),
  KEY `cl_timestamp` (`cl_to`,`cl_timestamp`),
  KEY `cl_collation_ext` (`cl_collation`,`cl_to`,`cl_type`,`cl_from`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mcategorylinks`
--

LOCK TABLES `m2mcategorylinks` WRITE;
/*!40000 ALTER TABLE `m2mcategorylinks` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mcategorylinks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mchange_tag`
--

DROP TABLE IF EXISTS `m2mchange_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mchange_tag` (
  `ct_id` int unsigned NOT NULL AUTO_INCREMENT,
  `ct_rc_id` int DEFAULT NULL,
  `ct_log_id` int unsigned DEFAULT NULL,
  `ct_rev_id` int unsigned DEFAULT NULL,
  `ct_params` blob,
  `ct_tag_id` int unsigned NOT NULL,
  PRIMARY KEY (`ct_id`),
  UNIQUE KEY `change_tag_rc_tag_id` (`ct_rc_id`,`ct_tag_id`),
  UNIQUE KEY `change_tag_log_tag_id` (`ct_log_id`,`ct_tag_id`),
  UNIQUE KEY `change_tag_rev_tag_id` (`ct_rev_id`,`ct_tag_id`),
  KEY `change_tag_tag_id_id` (`ct_tag_id`,`ct_rc_id`,`ct_rev_id`,`ct_log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mchange_tag`
--

LOCK TABLES `m2mchange_tag` WRITE;
/*!40000 ALTER TABLE `m2mchange_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mchange_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mchange_tag_def`
--

DROP TABLE IF EXISTS `m2mchange_tag_def`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mchange_tag_def` (
  `ctd_id` int unsigned NOT NULL AUTO_INCREMENT,
  `ctd_name` varbinary(255) NOT NULL,
  `ctd_user_defined` tinyint(1) NOT NULL,
  `ctd_count` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ctd_id`),
  UNIQUE KEY `ctd_name` (`ctd_name`),
  KEY `ctd_count` (`ctd_count`),
  KEY `ctd_user_defined` (`ctd_user_defined`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mchange_tag_def`
--

LOCK TABLES `m2mchange_tag_def` WRITE;
/*!40000 ALTER TABLE `m2mchange_tag_def` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mchange_tag_def` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mcomment`
--

DROP TABLE IF EXISTS `m2mcomment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mcomment` (
  `comment_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_hash` int NOT NULL,
  `comment_text` blob NOT NULL,
  `comment_data` blob,
  PRIMARY KEY (`comment_id`),
  KEY `comment_hash` (`comment_hash`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mcomment`
--

LOCK TABLES `m2mcomment` WRITE;
/*!40000 ALTER TABLE `m2mcomment` DISABLE KEYS */;
INSERT INTO `m2mcomment` VALUES (1,0,'',NULL);
/*!40000 ALTER TABLE `m2mcomment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mcontent`
--

DROP TABLE IF EXISTS `m2mcontent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mcontent` (
  `content_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `content_size` int unsigned NOT NULL,
  `content_sha1` varbinary(32) NOT NULL,
  `content_model` smallint unsigned NOT NULL,
  `content_address` varbinary(255) NOT NULL,
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mcontent`
--

LOCK TABLES `m2mcontent` WRITE;
/*!40000 ALTER TABLE `m2mcontent` DISABLE KEYS */;
INSERT INTO `m2mcontent` VALUES (1,819,_binary '40z2cdd6s997k9nvjghh8mxs0vdy8qq',1,_binary 'tt:1');
/*!40000 ALTER TABLE `m2mcontent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mcontent_models`
--

DROP TABLE IF EXISTS `m2mcontent_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mcontent_models` (
  `model_id` smallint NOT NULL AUTO_INCREMENT,
  `model_name` varbinary(64) NOT NULL,
  PRIMARY KEY (`model_id`),
  UNIQUE KEY `model_name` (`model_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mcontent_models`
--

LOCK TABLES `m2mcontent_models` WRITE;
/*!40000 ALTER TABLE `m2mcontent_models` DISABLE KEYS */;
INSERT INTO `m2mcontent_models` VALUES (1,_binary 'wikitext');
/*!40000 ALTER TABLE `m2mcontent_models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mexternallinks`
--

DROP TABLE IF EXISTS `m2mexternallinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mexternallinks` (
  `el_id` int unsigned NOT NULL AUTO_INCREMENT,
  `el_from` int unsigned NOT NULL DEFAULT '0',
  `el_to` blob NOT NULL,
  `el_index` blob NOT NULL,
  `el_index_60` varbinary(60) NOT NULL,
  PRIMARY KEY (`el_id`),
  KEY `el_from` (`el_from`,`el_to`(40)),
  KEY `el_to` (`el_to`(60),`el_from`),
  KEY `el_index` (`el_index`(60)),
  KEY `el_index_60` (`el_index_60`,`el_id`),
  KEY `el_from_index_60` (`el_from`,`el_index_60`,`el_id`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mexternallinks`
--

LOCK TABLES `m2mexternallinks` WRITE;
/*!40000 ALTER TABLE `m2mexternallinks` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mexternallinks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mfilearchive`
--

DROP TABLE IF EXISTS `m2mfilearchive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mfilearchive` (
  `fa_id` int NOT NULL AUTO_INCREMENT,
  `fa_name` varbinary(255) NOT NULL DEFAULT '',
  `fa_archive_name` varbinary(255) DEFAULT '',
  `fa_storage_group` varbinary(16) DEFAULT NULL,
  `fa_storage_key` varbinary(64) DEFAULT '',
  `fa_deleted_user` int DEFAULT NULL,
  `fa_deleted_timestamp` binary(14) DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `fa_deleted_reason_id` bigint unsigned NOT NULL,
  `fa_size` int unsigned DEFAULT '0',
  `fa_width` int DEFAULT '0',
  `fa_height` int DEFAULT '0',
  `fa_metadata` mediumblob,
  `fa_bits` int DEFAULT '0',
  `fa_media_type` enum('UNKNOWN','BITMAP','DRAWING','AUDIO','VIDEO','MULTIMEDIA','OFFICE','TEXT','EXECUTABLE','ARCHIVE','3D') DEFAULT NULL,
  `fa_major_mime` enum('unknown','application','audio','image','text','video','message','model','multipart','chemical') DEFAULT 'unknown',
  `fa_minor_mime` varbinary(100) DEFAULT 'unknown',
  `fa_description_id` bigint unsigned NOT NULL,
  `fa_actor` bigint unsigned NOT NULL,
  `fa_timestamp` binary(14) DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `fa_deleted` tinyint unsigned NOT NULL DEFAULT '0',
  `fa_sha1` varbinary(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`fa_id`),
  KEY `fa_name` (`fa_name`,`fa_timestamp`),
  KEY `fa_storage_group` (`fa_storage_group`,`fa_storage_key`),
  KEY `fa_deleted_timestamp` (`fa_deleted_timestamp`),
  KEY `fa_actor_timestamp` (`fa_actor`,`fa_timestamp`),
  KEY `fa_sha1` (`fa_sha1`(10))
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mfilearchive`
--

LOCK TABLES `m2mfilearchive` WRITE;
/*!40000 ALTER TABLE `m2mfilearchive` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mfilearchive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mimage`
--

DROP TABLE IF EXISTS `m2mimage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mimage` (
  `img_name` varbinary(255) NOT NULL DEFAULT '',
  `img_size` int unsigned NOT NULL DEFAULT '0',
  `img_width` int NOT NULL DEFAULT '0',
  `img_height` int NOT NULL DEFAULT '0',
  `img_metadata` mediumblob NOT NULL,
  `img_bits` int NOT NULL DEFAULT '0',
  `img_media_type` enum('UNKNOWN','BITMAP','DRAWING','AUDIO','VIDEO','MULTIMEDIA','OFFICE','TEXT','EXECUTABLE','ARCHIVE','3D') DEFAULT NULL,
  `img_major_mime` enum('unknown','application','audio','image','text','video','message','model','multipart','chemical') NOT NULL DEFAULT 'unknown',
  `img_minor_mime` varbinary(100) NOT NULL DEFAULT 'unknown',
  `img_description_id` bigint unsigned NOT NULL,
  `img_actor` bigint unsigned NOT NULL,
  `img_timestamp` varbinary(14) NOT NULL DEFAULT '',
  `img_sha1` varbinary(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`img_name`),
  KEY `img_actor_timestamp` (`img_actor`,`img_timestamp`),
  KEY `img_size` (`img_size`),
  KEY `img_timestamp` (`img_timestamp`),
  KEY `img_sha1` (`img_sha1`(10)),
  KEY `img_media_mime` (`img_media_type`,`img_major_mime`,`img_minor_mime`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mimage`
--

LOCK TABLES `m2mimage` WRITE;
/*!40000 ALTER TABLE `m2mimage` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mimage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mimagelinks`
--

DROP TABLE IF EXISTS `m2mimagelinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mimagelinks` (
  `il_from` int unsigned NOT NULL DEFAULT '0',
  `il_from_namespace` int NOT NULL DEFAULT '0',
  `il_to` varbinary(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`il_from`,`il_to`),
  KEY `il_to` (`il_to`,`il_from`),
  KEY `il_backlinks_namespace` (`il_from_namespace`,`il_to`,`il_from`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mimagelinks`
--

LOCK TABLES `m2mimagelinks` WRITE;
/*!40000 ALTER TABLE `m2mimagelinks` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mimagelinks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2minterwiki`
--

DROP TABLE IF EXISTS `m2minterwiki`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2minterwiki` (
  `iw_prefix` varbinary(32) NOT NULL,
  `iw_url` blob NOT NULL,
  `iw_api` blob NOT NULL,
  `iw_wikiid` varbinary(64) NOT NULL,
  `iw_local` tinyint(1) NOT NULL,
  `iw_trans` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`iw_prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2minterwiki`
--

LOCK TABLES `m2minterwiki` WRITE;
/*!40000 ALTER TABLE `m2minterwiki` DISABLE KEYS */;
INSERT INTO `m2minterwiki` VALUES (_binary 'acronym',_binary 'https://www.acronymfinder.com/~/search/af.aspx?string=exact&Acronym=$1','','',0,0),(_binary 'advogato',_binary 'http://www.advogato.org/$1','','',0,0),(_binary 'arxiv',_binary 'https://www.arxiv.org/abs/$1','','',0,0),(_binary 'c2find',_binary 'http://c2.com/cgi/wiki?FindPage&value=$1','','',0,0),(_binary 'cache',_binary 'https://www.google.com/search?q=cache:$1','','',0,0),(_binary 'commons',_binary 'https://commons.wikimedia.org/wiki/$1',_binary 'https://commons.wikimedia.org/w/api.php','',0,0),(_binary 'dictionary',_binary 'http://www.dict.org/bin/Dict?Database=*&Form=Dict1&Strategy=*&Query=$1','','',0,0),(_binary 'doi',_binary 'https://dx.doi.org/$1','','',0,0),(_binary 'drumcorpswiki',_binary 'http://www.drumcorpswiki.com/$1',_binary 'http://drumcorpswiki.com/api.php','',0,0),(_binary 'dwjwiki',_binary 'http://www.suberic.net/cgi-bin/dwj/wiki.cgi?$1','','',0,0),(_binary 'elibre',_binary 'http://enciclopedia.us.es/index.php/$1',_binary 'http://enciclopedia.us.es/api.php','',0,0),(_binary 'emacswiki',_binary 'https://www.emacswiki.org/emacs/$1','','',0,0),(_binary 'foldoc',_binary 'https://foldoc.org/?$1','','',0,0),(_binary 'foxwiki',_binary 'https://fox.wikis.com/wc.dll?Wiki~$1','','',0,0),(_binary 'freebsdman',_binary 'https://www.FreeBSD.org/cgi/man.cgi?apropos=1&query=$1','','',0,0),(_binary 'gentoo-wiki',_binary 'http://gentoo-wiki.com/$1','','',0,0),(_binary 'google',_binary 'https://www.google.com/search?q=$1','','',0,0),(_binary 'googlegroups',_binary 'https://groups.google.com/groups?q=$1','','',0,0),(_binary 'hammondwiki',_binary 'http://www.dairiki.org/HammondWiki/$1','','',0,0),(_binary 'hrwiki',_binary 'http://www.hrwiki.org/wiki/$1',_binary 'http://www.hrwiki.org/w/api.php','',0,0),(_binary 'imdb',_binary 'http://www.imdb.com/find?q=$1&tt=on','','',0,0),(_binary 'kmwiki',_binary 'https://kmwiki.wikispaces.com/$1','','',0,0),(_binary 'linuxwiki',_binary 'http://linuxwiki.de/$1','','',0,0),(_binary 'lojban',_binary 'https://mw.lojban.org/papri/$1','','',0,0),(_binary 'lqwiki',_binary 'http://wiki.linuxquestions.org/wiki/$1','','',0,0),(_binary 'meatball',_binary 'http://www.usemod.com/cgi-bin/mb.pl?$1','','',0,0),(_binary 'mediawikiwiki',_binary 'https://www.mediawiki.org/wiki/$1',_binary 'https://www.mediawiki.org/w/api.php','',0,0),(_binary 'memoryalpha',_binary 'http://en.memory-alpha.org/wiki/$1',_binary 'http://en.memory-alpha.org/api.php','',0,0),(_binary 'metawiki',_binary 'http://sunir.org/apps/meta.pl?$1','','',0,0),(_binary 'metawikimedia',_binary 'https://meta.wikimedia.org/wiki/$1',_binary 'https://meta.wikimedia.org/w/api.php','',0,0),(_binary 'mozillawiki',_binary 'https://wiki.mozilla.org/$1',_binary 'https://wiki.mozilla.org/api.php','',0,0),(_binary 'mw',_binary 'https://www.mediawiki.org/wiki/$1',_binary 'https://www.mediawiki.org/w/api.php','',0,0),(_binary 'oeis',_binary 'https://oeis.org/$1','','',0,0),(_binary 'openwiki',_binary 'http://openwiki.com/ow.asp?$1','','',0,0),(_binary 'pmid',_binary 'https://www.ncbi.nlm.nih.gov/pubmed/$1?dopt=Abstract','','',0,0),(_binary 'pythoninfo',_binary 'https://wiki.python.org/moin/$1','','',0,0),(_binary 'rfc',_binary 'https://tools.ietf.org/html/rfc$1','','',0,0),(_binary 's23wiki',_binary 'http://s23.org/wiki/$1',_binary 'http://s23.org/w/api.php','',0,0),(_binary 'seattlewireless',_binary 'http://seattlewireless.net/$1','','',0,0),(_binary 'senseislibrary',_binary 'https://senseis.xmp.net/?$1','','',0,0),(_binary 'shoutwiki',_binary 'http://www.shoutwiki.com/wiki/$1',_binary 'http://www.shoutwiki.com/w/api.php','',0,0),(_binary 'squeak',_binary 'http://wiki.squeak.org/squeak/$1','','',0,0),(_binary 'theopedia',_binary 'https://www.theopedia.com/$1','','',0,0),(_binary 'tmbw',_binary 'http://www.tmbw.net/wiki/$1',_binary 'http://tmbw.net/wiki/api.php','',0,0),(_binary 'tmnet',_binary 'http://www.technomanifestos.net/?$1','','',0,0),(_binary 'twiki',_binary 'http://twiki.org/cgi-bin/view/$1','','',0,0),(_binary 'uncyclopedia',_binary 'https://en.uncyclopedia.co/wiki/$1',_binary 'https://en.uncyclopedia.co/w/api.php','',0,0),(_binary 'unreal',_binary 'https://wiki.beyondunreal.com/$1',_binary 'https://wiki.beyondunreal.com/w/api.php','',0,0),(_binary 'usemod',_binary 'http://www.usemod.com/cgi-bin/wiki.pl?$1','','',0,0),(_binary 'wiki',_binary 'http://c2.com/cgi/wiki?$1','','',0,0),(_binary 'wikia',_binary 'http://www.wikia.com/wiki/$1','','',0,0),(_binary 'wikibooks',_binary 'https://en.wikibooks.org/wiki/$1',_binary 'https://en.wikibooks.org/w/api.php','',0,0),(_binary 'wikidata',_binary 'https://www.wikidata.org/wiki/$1',_binary 'https://www.wikidata.org/w/api.php','',0,0),(_binary 'wikif1',_binary 'http://www.wikif1.org/$1','','',0,0),(_binary 'wikihow',_binary 'https://www.wikihow.com/$1',_binary 'https://www.wikihow.com/api.php','',0,0),(_binary 'wikimedia',_binary 'https://foundation.wikimedia.org/wiki/$1',_binary 'https://foundation.wikimedia.org/w/api.php','',0,0),(_binary 'wikinews',_binary 'https://en.wikinews.org/wiki/$1',_binary 'https://en.wikinews.org/w/api.php','',0,0),(_binary 'wikinfo',_binary 'http://wikinfo.co/English/index.php/$1','','',0,0),(_binary 'wikipedia',_binary 'https://en.wikipedia.org/wiki/$1',_binary 'https://en.wikipedia.org/w/api.php','',0,0),(_binary 'wikiquote',_binary 'https://en.wikiquote.org/wiki/$1',_binary 'https://en.wikiquote.org/w/api.php','',0,0),(_binary 'wikisource',_binary 'https://wikisource.org/wiki/$1',_binary 'https://wikisource.org/w/api.php','',0,0),(_binary 'wikispecies',_binary 'https://species.wikimedia.org/wiki/$1',_binary 'https://species.wikimedia.org/w/api.php','',0,0),(_binary 'wikiversity',_binary 'https://en.wikiversity.org/wiki/$1',_binary 'https://en.wikiversity.org/w/api.php','',0,0),(_binary 'wikivoyage',_binary 'https://en.wikivoyage.org/wiki/$1',_binary 'https://en.wikivoyage.org/w/api.php','',0,0),(_binary 'wikt',_binary 'https://en.wiktionary.org/wiki/$1',_binary 'https://en.wiktionary.org/w/api.php','',0,0),(_binary 'wiktionary',_binary 'https://en.wiktionary.org/wiki/$1',_binary 'https://en.wiktionary.org/w/api.php','',0,0);
/*!40000 ALTER TABLE `m2minterwiki` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mip_changes`
--

DROP TABLE IF EXISTS `m2mip_changes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mip_changes` (
  `ipc_rev_id` int unsigned NOT NULL DEFAULT '0',
  `ipc_rev_timestamp` binary(14) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ipc_hex` varbinary(35) NOT NULL DEFAULT '',
  PRIMARY KEY (`ipc_rev_id`),
  KEY `ipc_rev_timestamp` (`ipc_rev_timestamp`),
  KEY `ipc_hex_time` (`ipc_hex`,`ipc_rev_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mip_changes`
--

LOCK TABLES `m2mip_changes` WRITE;
/*!40000 ALTER TABLE `m2mip_changes` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mip_changes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mipblocks`
--

DROP TABLE IF EXISTS `m2mipblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mipblocks` (
  `ipb_id` int NOT NULL AUTO_INCREMENT,
  `ipb_address` tinyblob NOT NULL,
  `ipb_user` int unsigned NOT NULL DEFAULT '0',
  `ipb_by_actor` bigint unsigned NOT NULL,
  `ipb_reason_id` bigint unsigned NOT NULL,
  `ipb_timestamp` binary(14) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ipb_auto` tinyint(1) NOT NULL DEFAULT '0',
  `ipb_anon_only` tinyint(1) NOT NULL DEFAULT '0',
  `ipb_create_account` tinyint(1) NOT NULL DEFAULT '1',
  `ipb_enable_autoblock` tinyint(1) NOT NULL DEFAULT '1',
  `ipb_expiry` varbinary(14) NOT NULL DEFAULT '',
  `ipb_range_start` tinyblob NOT NULL,
  `ipb_range_end` tinyblob NOT NULL,
  `ipb_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `ipb_block_email` tinyint(1) NOT NULL DEFAULT '0',
  `ipb_allow_usertalk` tinyint(1) NOT NULL DEFAULT '0',
  `ipb_parent_block_id` int DEFAULT NULL,
  `ipb_sitewide` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ipb_id`),
  UNIQUE KEY `ipb_address_unique` (`ipb_address`(255),`ipb_user`,`ipb_auto`),
  KEY `ipb_user` (`ipb_user`),
  KEY `ipb_range` (`ipb_range_start`(8),`ipb_range_end`(8)),
  KEY `ipb_timestamp` (`ipb_timestamp`),
  KEY `ipb_expiry` (`ipb_expiry`),
  KEY `ipb_parent_block_id` (`ipb_parent_block_id`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mipblocks`
--

LOCK TABLES `m2mipblocks` WRITE;
/*!40000 ALTER TABLE `m2mipblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mipblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mipblocks_restrictions`
--

DROP TABLE IF EXISTS `m2mipblocks_restrictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mipblocks_restrictions` (
  `ir_ipb_id` int NOT NULL,
  `ir_type` tinyint(1) NOT NULL,
  `ir_value` int NOT NULL,
  PRIMARY KEY (`ir_ipb_id`,`ir_type`,`ir_value`),
  KEY `ir_type_value` (`ir_type`,`ir_value`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mipblocks_restrictions`
--

LOCK TABLES `m2mipblocks_restrictions` WRITE;
/*!40000 ALTER TABLE `m2mipblocks_restrictions` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mipblocks_restrictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2miwlinks`
--

DROP TABLE IF EXISTS `m2miwlinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2miwlinks` (
  `iwl_from` int unsigned NOT NULL DEFAULT '0',
  `iwl_prefix` varbinary(32) NOT NULL DEFAULT '',
  `iwl_title` varbinary(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`iwl_from`,`iwl_prefix`,`iwl_title`),
  KEY `iwl_prefix_title_from` (`iwl_prefix`,`iwl_title`,`iwl_from`),
  KEY `iwl_prefix_from_title` (`iwl_prefix`,`iwl_from`,`iwl_title`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2miwlinks`
--

LOCK TABLES `m2miwlinks` WRITE;
/*!40000 ALTER TABLE `m2miwlinks` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2miwlinks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mjob`
--

DROP TABLE IF EXISTS `m2mjob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mjob` (
  `job_id` int unsigned NOT NULL AUTO_INCREMENT,
  `job_cmd` varbinary(60) NOT NULL DEFAULT '',
  `job_namespace` int NOT NULL,
  `job_title` varbinary(255) NOT NULL,
  `job_timestamp` varbinary(14) DEFAULT NULL,
  `job_params` mediumblob NOT NULL,
  `job_random` int unsigned NOT NULL DEFAULT '0',
  `job_attempts` int unsigned NOT NULL DEFAULT '0',
  `job_token` varbinary(32) NOT NULL DEFAULT '',
  `job_token_timestamp` varbinary(14) DEFAULT NULL,
  `job_sha1` varbinary(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`job_id`),
  KEY `job_sha1` (`job_sha1`),
  KEY `job_cmd_token` (`job_cmd`,`job_token`,`job_random`),
  KEY `job_cmd_token_id` (`job_cmd`,`job_token`,`job_id`),
  KEY `job_cmd` (`job_cmd`,`job_namespace`,`job_title`,`job_params`(128)),
  KEY `job_timestamp` (`job_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mjob`
--

LOCK TABLES `m2mjob` WRITE;
/*!40000 ALTER TABLE `m2mjob` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mjob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2ml10n_cache`
--

DROP TABLE IF EXISTS `m2ml10n_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2ml10n_cache` (
  `lc_lang` varbinary(35) NOT NULL,
  `lc_key` varbinary(255) NOT NULL,
  `lc_value` mediumblob NOT NULL,
  PRIMARY KEY (`lc_lang`,`lc_key`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2ml10n_cache`
--

LOCK TABLES `m2ml10n_cache` WRITE;
/*!40000 ALTER TABLE `m2ml10n_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2ml10n_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mlanglinks`
--

DROP TABLE IF EXISTS `m2mlanglinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mlanglinks` (
  `ll_from` int unsigned NOT NULL DEFAULT '0',
  `ll_lang` varbinary(35) NOT NULL DEFAULT '',
  `ll_title` varbinary(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`ll_from`,`ll_lang`),
  KEY `ll_lang` (`ll_lang`,`ll_title`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mlanglinks`
--

LOCK TABLES `m2mlanglinks` WRITE;
/*!40000 ALTER TABLE `m2mlanglinks` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mlanglinks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mlog_search`
--

DROP TABLE IF EXISTS `m2mlog_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mlog_search` (
  `ls_field` varbinary(32) NOT NULL,
  `ls_value` varbinary(255) NOT NULL,
  `ls_log_id` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ls_field`,`ls_value`,`ls_log_id`),
  KEY `ls_log_id` (`ls_log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mlog_search`
--

LOCK TABLES `m2mlog_search` WRITE;
/*!40000 ALTER TABLE `m2mlog_search` DISABLE KEYS */;
INSERT INTO `m2mlog_search` VALUES (_binary 'associated_rev_id',_binary '1',1);
/*!40000 ALTER TABLE `m2mlog_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mlogging`
--

DROP TABLE IF EXISTS `m2mlogging`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mlogging` (
  `log_id` int unsigned NOT NULL AUTO_INCREMENT,
  `log_type` varbinary(32) NOT NULL DEFAULT '',
  `log_action` varbinary(32) NOT NULL DEFAULT '',
  `log_timestamp` binary(14) NOT NULL DEFAULT '19700101000000',
  `log_actor` bigint unsigned NOT NULL,
  `log_namespace` int NOT NULL DEFAULT '0',
  `log_title` varbinary(255) NOT NULL DEFAULT '',
  `log_page` int unsigned DEFAULT NULL,
  `log_comment_id` bigint unsigned NOT NULL,
  `log_params` blob NOT NULL,
  `log_deleted` tinyint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`log_id`),
  KEY `type_time` (`log_type`,`log_timestamp`),
  KEY `actor_time` (`log_actor`,`log_timestamp`),
  KEY `page_time` (`log_namespace`,`log_title`,`log_timestamp`),
  KEY `times` (`log_timestamp`),
  KEY `log_actor_type_time` (`log_actor`,`log_type`,`log_timestamp`),
  KEY `log_page_id_time` (`log_page`,`log_timestamp`),
  KEY `log_type_action` (`log_type`,`log_action`,`log_timestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mlogging`
--

LOCK TABLES `m2mlogging` WRITE;
/*!40000 ALTER TABLE `m2mlogging` DISABLE KEYS */;
INSERT INTO `m2mlogging` VALUES (1,_binary 'create',_binary 'create',_binary '20241227194233',2,0,_binary 'Pàgina_principal',1,1,_binary 'a:1:{s:17:\"associated_rev_id\";i:1;}',0);
/*!40000 ALTER TABLE `m2mlogging` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mmodule_deps`
--

DROP TABLE IF EXISTS `m2mmodule_deps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mmodule_deps` (
  `md_module` varbinary(255) NOT NULL,
  `md_skin` varbinary(32) NOT NULL,
  `md_deps` mediumblob NOT NULL,
  PRIMARY KEY (`md_module`,`md_skin`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mmodule_deps`
--

LOCK TABLES `m2mmodule_deps` WRITE;
/*!40000 ALTER TABLE `m2mmodule_deps` DISABLE KEYS */;
INSERT INTO `m2mmodule_deps` VALUES (_binary 'mediawiki.htmlform.styles',_binary 'vector|ca',_binary '[\"resources/src/mediawiki.htmlform.styles/images/question.png\",\"resources/src/mediawiki.htmlform.styles/images/question.svg\",\"resources/src/mediawiki.less/mediawiki.mixins.less\"]'),(_binary 'mediawiki.special.userlogin.common.styles',_binary 'vector|ca',_binary '[\"resources/src/mediawiki.special.userlogin.common.styles/images/icon-lock.png\"]'),(_binary 'mediawiki.special.userlogin.login.styles',_binary 'vector|ca',_binary '[\"resources/src/mediawiki.special.userlogin.login.styles/images/glyph-people-large.png\"]'),(_binary 'mediawiki.ui',_binary 'vector|ca',_binary '[\"resources/src/mediawiki.less/mediawiki.mixins.less\",\"resources/src/mediawiki.less/mediawiki.ui/variables.less\",\"resources/src/mediawiki.ui/components/forms.less\",\"resources/src/mediawiki.ui/components/utilities.less\"]'),(_binary 'mediawiki.ui.button',_binary 'vector|ca',_binary '[\"resources/src/mediawiki.less/mediawiki.mixins.less\",\"resources/src/mediawiki.less/mediawiki.ui/mixins.buttons.less\",\"resources/src/mediawiki.less/mediawiki.ui/variables.less\"]'),(_binary 'mediawiki.ui.checkbox',_binary 'vector|ca',_binary '[\"resources/src/mediawiki.less/mediawiki.mixins.less\",\"resources/src/mediawiki.less/mediawiki.ui/variables.less\",\"resources/src/mediawiki.ui/components/images/checkbox-checked.png\",\"resources/src/mediawiki.ui/components/images/checkbox-checked.svg\"]'),(_binary 'mediawiki.ui.input',_binary 'vector|ca',_binary '[\"resources/src/mediawiki.less/mediawiki.mixins.less\",\"resources/src/mediawiki.less/mediawiki.ui/variables.less\"]'),(_binary 'mediawiki.ui.radio',_binary 'vector|ca',_binary '[\"resources/src/mediawiki.less/mediawiki.mixins.less\",\"resources/src/mediawiki.less/mediawiki.ui/variables.less\"]'),(_binary 'skins.vector.styles.legacy',_binary 'vector|ca',_binary '[\"resources/src/mediawiki.less/mediawiki.mixins.animation.less\",\"resources/src/mediawiki.less/mediawiki.mixins.less\",\"resources/src/mediawiki.less/mediawiki.mixins.rotation.less\",\"resources/src/mediawiki.less/mediawiki.ui/variables.less\",\"resources/src/mediawiki.skinning/i18n-all-lists-margins.less\",\"resources/src/mediawiki.skinning/i18n-headings.less\",\"resources/src/mediawiki.skinning/i18n-ordered-lists.less\",\"resources/src/mediawiki.skinning/images/ajax-loader.gif\",\"resources/src/mediawiki.skinning/images/magnify-clip-ltr.png\",\"resources/src/mediawiki.skinning/images/magnify-clip-ltr.svg\",\"resources/src/mediawiki.skinning/images/magnify-clip-rtl.png\",\"resources/src/mediawiki.skinning/images/magnify-clip-rtl.svg\",\"resources/src/mediawiki.skinning/images/spinner.gif\",\"skins/Vector/resources/skins.vector.styles/Footer.less\",\"skins/Vector/resources/skins.vector.styles/Indicators.less\",\"skins/Vector/resources/skins.vector.styles/Menu.less\",\"skins/Vector/resources/skins.vector.styles/MenuDropdown.less\",\"skins/Vector/resources/skins.vector.styles/MenuPortal.less\",\"skins/Vector/resources/skins.vector.styles/MenuTabs.less\",\"skins/Vector/resources/skins.vector.styles/SearchBox.less\",\"skins/Vector/resources/skins.vector.styles/SidebarLogo.less\",\"skins/Vector/resources/skins.vector.styles/SiteNotice.less\",\"skins/Vector/resources/skins.vector.styles/TabWatchstarLink-ie8.less\",\"skins/Vector/resources/skins.vector.styles/TabWatchstarLink.less\",\"skins/Vector/resources/skins.vector.styles/common/normalize.less\",\"skins/Vector/resources/skins.vector.styles/common/print.less\",\"skins/Vector/resources/skins.vector.styles/common/typography.less\",\"skins/Vector/resources/skins.vector.styles/images/arrow-down.png\",\"skins/Vector/resources/skins.vector.styles/images/arrow-down.svg\",\"skins/Vector/resources/skins.vector.styles/images/bullet-icon.svg\",\"skins/Vector/resources/skins.vector.styles/images/external-link-ltr-icon.png\",\"skins/Vector/resources/skins.vector.styles/images/external-link-ltr-icon.svg\",\"skins/Vector/resources/skins.vector.styles/images/portal-separator.png\",\"skins/Vector/resources/skins.vector.styles/images/search.png\",\"skins/Vector/resources/skins.vector.styles/images/search.svg\",\"skins/Vector/resources/skins.vector.styles/images/tab-current-fade.png\",\"skins/Vector/resources/skins.vector.styles/images/tab-normal-fade.png\",\"skins/Vector/resources/skins.vector.styles/images/tab-separator.png\",\"skins/Vector/resources/skins.vector.styles/images/unwatch-icon-hl.svg\",\"skins/Vector/resources/skins.vector.styles/images/unwatch-icon.svg\",\"skins/Vector/resources/skins.vector.styles/images/unwatch-temp-icon-hl.svg\",\"skins/Vector/resources/skins.vector.styles/images/unwatch-temp-icon.svg\",\"skins/Vector/resources/skins.vector.styles/images/user-avatar.png\",\"skins/Vector/resources/skins.vector.styles/images/user-avatar.svg\",\"skins/Vector/resources/skins.vector.styles/images/watch-icon-hl.svg\",\"skins/Vector/resources/skins.vector.styles/images/watch-icon.svg\",\"skins/Vector/resources/skins.vector.styles/legacy/Sidebar.less\",\"skins/Vector/resources/skins.vector.styles/legacy/layout.less\",\"skins/Vector/variables.less\"]');
/*!40000 ALTER TABLE `m2mmodule_deps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mobjectcache`
--

DROP TABLE IF EXISTS `m2mobjectcache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mobjectcache` (
  `keyname` varbinary(255) NOT NULL DEFAULT '',
  `value` mediumblob,
  `exptime` datetime DEFAULT NULL,
  PRIMARY KEY (`keyname`),
  KEY `exptime` (`exptime`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mobjectcache`
--

LOCK TABLES `m2mobjectcache` WRITE;
/*!40000 ALTER TABLE `m2mobjectcache` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mobjectcache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2moldimage`
--

DROP TABLE IF EXISTS `m2moldimage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2moldimage` (
  `oi_name` varbinary(255) NOT NULL DEFAULT '',
  `oi_archive_name` varbinary(255) NOT NULL DEFAULT '',
  `oi_size` int unsigned NOT NULL DEFAULT '0',
  `oi_width` int NOT NULL DEFAULT '0',
  `oi_height` int NOT NULL DEFAULT '0',
  `oi_bits` int NOT NULL DEFAULT '0',
  `oi_description_id` bigint unsigned NOT NULL,
  `oi_actor` bigint unsigned NOT NULL,
  `oi_timestamp` binary(14) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `oi_metadata` mediumblob NOT NULL,
  `oi_media_type` enum('UNKNOWN','BITMAP','DRAWING','AUDIO','VIDEO','MULTIMEDIA','OFFICE','TEXT','EXECUTABLE','ARCHIVE','3D') DEFAULT NULL,
  `oi_major_mime` enum('unknown','application','audio','image','text','video','message','model','multipart','chemical') NOT NULL DEFAULT 'unknown',
  `oi_minor_mime` varbinary(100) NOT NULL DEFAULT 'unknown',
  `oi_deleted` tinyint unsigned NOT NULL DEFAULT '0',
  `oi_sha1` varbinary(32) NOT NULL DEFAULT '',
  KEY `oi_actor_timestamp` (`oi_actor`,`oi_timestamp`),
  KEY `oi_name_timestamp` (`oi_name`,`oi_timestamp`),
  KEY `oi_name_archive_name` (`oi_name`,`oi_archive_name`(14)),
  KEY `oi_sha1` (`oi_sha1`(10))
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2moldimage`
--

LOCK TABLES `m2moldimage` WRITE;
/*!40000 ALTER TABLE `m2moldimage` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2moldimage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mpage`
--

DROP TABLE IF EXISTS `m2mpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mpage` (
  `page_id` int unsigned NOT NULL AUTO_INCREMENT,
  `page_namespace` int NOT NULL,
  `page_title` varbinary(255) NOT NULL,
  `page_restrictions` tinyblob,
  `page_is_redirect` tinyint unsigned NOT NULL DEFAULT '0',
  `page_is_new` tinyint unsigned NOT NULL DEFAULT '0',
  `page_random` double unsigned NOT NULL,
  `page_touched` binary(14) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `page_links_updated` varbinary(14) DEFAULT NULL,
  `page_latest` int unsigned NOT NULL,
  `page_len` int unsigned NOT NULL,
  `page_content_model` varbinary(32) DEFAULT NULL,
  `page_lang` varbinary(35) DEFAULT NULL,
  PRIMARY KEY (`page_id`),
  UNIQUE KEY `name_title` (`page_namespace`,`page_title`),
  KEY `page_random` (`page_random`),
  KEY `page_len` (`page_len`),
  KEY `page_redirect_namespace_len` (`page_is_redirect`,`page_namespace`,`page_len`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mpage`
--

LOCK TABLES `m2mpage` WRITE;
/*!40000 ALTER TABLE `m2mpage` DISABLE KEYS */;
INSERT INTO `m2mpage` VALUES (1,0,_binary 'Pàgina_principal','',0,1,0.099977256976,_binary '20241227194233',NULL,1,819,_binary 'wikitext',NULL);
/*!40000 ALTER TABLE `m2mpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mpage_props`
--

DROP TABLE IF EXISTS `m2mpage_props`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mpage_props` (
  `pp_page` int NOT NULL,
  `pp_propname` varbinary(60) NOT NULL,
  `pp_value` blob NOT NULL,
  `pp_sortkey` float DEFAULT NULL,
  PRIMARY KEY (`pp_page`,`pp_propname`),
  UNIQUE KEY `pp_propname_page` (`pp_propname`,`pp_page`),
  UNIQUE KEY `pp_propname_sortkey_page` (`pp_propname`,`pp_sortkey`,`pp_page`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mpage_props`
--

LOCK TABLES `m2mpage_props` WRITE;
/*!40000 ALTER TABLE `m2mpage_props` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mpage_props` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mpage_restrictions`
--

DROP TABLE IF EXISTS `m2mpage_restrictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mpage_restrictions` (
  `pr_id` int unsigned NOT NULL AUTO_INCREMENT,
  `pr_page` int NOT NULL,
  `pr_type` varbinary(60) NOT NULL,
  `pr_level` varbinary(60) NOT NULL,
  `pr_cascade` tinyint NOT NULL,
  `pr_user` int unsigned DEFAULT NULL,
  `pr_expiry` varbinary(14) DEFAULT NULL,
  PRIMARY KEY (`pr_id`),
  UNIQUE KEY `pr_pagetype` (`pr_page`,`pr_type`),
  KEY `pr_typelevel` (`pr_type`,`pr_level`),
  KEY `pr_level` (`pr_level`),
  KEY `pr_cascade` (`pr_cascade`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mpage_restrictions`
--

LOCK TABLES `m2mpage_restrictions` WRITE;
/*!40000 ALTER TABLE `m2mpage_restrictions` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mpage_restrictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mpagelinks`
--

DROP TABLE IF EXISTS `m2mpagelinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mpagelinks` (
  `pl_from` int unsigned NOT NULL DEFAULT '0',
  `pl_from_namespace` int NOT NULL DEFAULT '0',
  `pl_namespace` int NOT NULL DEFAULT '0',
  `pl_title` varbinary(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`pl_from`,`pl_namespace`,`pl_title`),
  KEY `pl_namespace` (`pl_namespace`,`pl_title`,`pl_from`),
  KEY `pl_backlinks_namespace` (`pl_from_namespace`,`pl_namespace`,`pl_title`,`pl_from`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mpagelinks`
--

LOCK TABLES `m2mpagelinks` WRITE;
/*!40000 ALTER TABLE `m2mpagelinks` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mpagelinks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mprotected_titles`
--

DROP TABLE IF EXISTS `m2mprotected_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mprotected_titles` (
  `pt_namespace` int NOT NULL,
  `pt_title` varbinary(255) NOT NULL,
  `pt_user` int unsigned NOT NULL,
  `pt_reason_id` bigint unsigned NOT NULL,
  `pt_timestamp` binary(14) NOT NULL,
  `pt_expiry` varbinary(14) NOT NULL DEFAULT '',
  `pt_create_perm` varbinary(60) NOT NULL,
  PRIMARY KEY (`pt_namespace`,`pt_title`),
  KEY `pt_timestamp` (`pt_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mprotected_titles`
--

LOCK TABLES `m2mprotected_titles` WRITE;
/*!40000 ALTER TABLE `m2mprotected_titles` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mprotected_titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mquerycache`
--

DROP TABLE IF EXISTS `m2mquerycache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mquerycache` (
  `qc_type` varbinary(32) NOT NULL,
  `qc_value` int unsigned NOT NULL DEFAULT '0',
  `qc_namespace` int NOT NULL DEFAULT '0',
  `qc_title` varbinary(255) NOT NULL DEFAULT '',
  KEY `qc_type` (`qc_type`,`qc_value`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mquerycache`
--

LOCK TABLES `m2mquerycache` WRITE;
/*!40000 ALTER TABLE `m2mquerycache` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mquerycache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mquerycache_info`
--

DROP TABLE IF EXISTS `m2mquerycache_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mquerycache_info` (
  `qci_type` varbinary(32) NOT NULL DEFAULT '',
  `qci_timestamp` binary(14) NOT NULL DEFAULT '19700101000000',
  PRIMARY KEY (`qci_type`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mquerycache_info`
--

LOCK TABLES `m2mquerycache_info` WRITE;
/*!40000 ALTER TABLE `m2mquerycache_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mquerycache_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mquerycachetwo`
--

DROP TABLE IF EXISTS `m2mquerycachetwo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mquerycachetwo` (
  `qcc_type` varbinary(32) NOT NULL,
  `qcc_value` int unsigned NOT NULL DEFAULT '0',
  `qcc_namespace` int NOT NULL DEFAULT '0',
  `qcc_title` varbinary(255) NOT NULL DEFAULT '',
  `qcc_namespacetwo` int NOT NULL DEFAULT '0',
  `qcc_titletwo` varbinary(255) NOT NULL DEFAULT '',
  KEY `qcc_type` (`qcc_type`,`qcc_value`),
  KEY `qcc_title` (`qcc_type`,`qcc_namespace`,`qcc_title`),
  KEY `qcc_titletwo` (`qcc_type`,`qcc_namespacetwo`,`qcc_titletwo`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mquerycachetwo`
--

LOCK TABLES `m2mquerycachetwo` WRITE;
/*!40000 ALTER TABLE `m2mquerycachetwo` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mquerycachetwo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mrecentchanges`
--

DROP TABLE IF EXISTS `m2mrecentchanges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mrecentchanges` (
  `rc_id` int NOT NULL AUTO_INCREMENT,
  `rc_timestamp` varbinary(14) NOT NULL DEFAULT '',
  `rc_actor` bigint unsigned NOT NULL,
  `rc_namespace` int NOT NULL DEFAULT '0',
  `rc_title` varbinary(255) NOT NULL DEFAULT '',
  `rc_comment_id` bigint unsigned NOT NULL,
  `rc_minor` tinyint unsigned NOT NULL DEFAULT '0',
  `rc_bot` tinyint unsigned NOT NULL DEFAULT '0',
  `rc_new` tinyint unsigned NOT NULL DEFAULT '0',
  `rc_cur_id` int unsigned NOT NULL DEFAULT '0',
  `rc_this_oldid` int unsigned NOT NULL DEFAULT '0',
  `rc_last_oldid` int unsigned NOT NULL DEFAULT '0',
  `rc_type` tinyint unsigned NOT NULL DEFAULT '0',
  `rc_source` varbinary(16) NOT NULL DEFAULT '',
  `rc_patrolled` tinyint unsigned NOT NULL DEFAULT '0',
  `rc_ip` varbinary(40) NOT NULL DEFAULT '',
  `rc_old_len` int DEFAULT NULL,
  `rc_new_len` int DEFAULT NULL,
  `rc_deleted` tinyint unsigned NOT NULL DEFAULT '0',
  `rc_logid` int unsigned NOT NULL DEFAULT '0',
  `rc_log_type` varbinary(255) DEFAULT NULL,
  `rc_log_action` varbinary(255) DEFAULT NULL,
  `rc_params` blob,
  PRIMARY KEY (`rc_id`),
  KEY `rc_timestamp` (`rc_timestamp`),
  KEY `rc_namespace_title_timestamp` (`rc_namespace`,`rc_title`,`rc_timestamp`),
  KEY `rc_cur_id` (`rc_cur_id`),
  KEY `new_name_timestamp` (`rc_new`,`rc_namespace`,`rc_timestamp`),
  KEY `rc_ip` (`rc_ip`),
  KEY `rc_ns_actor` (`rc_namespace`,`rc_actor`),
  KEY `rc_actor` (`rc_actor`,`rc_timestamp`),
  KEY `rc_name_type_patrolled_timestamp` (`rc_namespace`,`rc_type`,`rc_patrolled`,`rc_timestamp`),
  KEY `rc_this_oldid` (`rc_this_oldid`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mrecentchanges`
--

LOCK TABLES `m2mrecentchanges` WRITE;
/*!40000 ALTER TABLE `m2mrecentchanges` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mrecentchanges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mredirect`
--

DROP TABLE IF EXISTS `m2mredirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mredirect` (
  `rd_from` int unsigned NOT NULL DEFAULT '0',
  `rd_namespace` int NOT NULL DEFAULT '0',
  `rd_title` varbinary(255) NOT NULL DEFAULT '',
  `rd_interwiki` varbinary(32) DEFAULT NULL,
  `rd_fragment` varbinary(255) DEFAULT NULL,
  PRIMARY KEY (`rd_from`),
  KEY `rd_ns_title` (`rd_namespace`,`rd_title`,`rd_from`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mredirect`
--

LOCK TABLES `m2mredirect` WRITE;
/*!40000 ALTER TABLE `m2mredirect` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mredirect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mrevision`
--

DROP TABLE IF EXISTS `m2mrevision`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mrevision` (
  `rev_id` int unsigned NOT NULL AUTO_INCREMENT,
  `rev_page` int unsigned NOT NULL,
  `rev_comment_id` bigint unsigned NOT NULL DEFAULT '0',
  `rev_actor` bigint unsigned NOT NULL DEFAULT '0',
  `rev_timestamp` binary(14) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `rev_minor_edit` tinyint unsigned NOT NULL DEFAULT '0',
  `rev_deleted` tinyint unsigned NOT NULL DEFAULT '0',
  `rev_len` int unsigned DEFAULT NULL,
  `rev_parent_id` int unsigned DEFAULT NULL,
  `rev_sha1` varbinary(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`rev_id`),
  KEY `rev_page_id` (`rev_page`,`rev_id`),
  KEY `rev_timestamp` (`rev_timestamp`),
  KEY `page_timestamp` (`rev_page`,`rev_timestamp`),
  KEY `rev_actor_timestamp` (`rev_actor`,`rev_timestamp`,`rev_id`),
  KEY `rev_page_actor_timestamp` (`rev_page`,`rev_actor`,`rev_timestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=binary MAX_ROWS=10000000 AVG_ROW_LENGTH=1024;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mrevision`
--

LOCK TABLES `m2mrevision` WRITE;
/*!40000 ALTER TABLE `m2mrevision` DISABLE KEYS */;
INSERT INTO `m2mrevision` VALUES (1,1,0,0,_binary '20241227194233',0,0,819,0,_binary '40z2cdd6s997k9nvjghh8mxs0vdy8qq');
/*!40000 ALTER TABLE `m2mrevision` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mrevision_actor_temp`
--

DROP TABLE IF EXISTS `m2mrevision_actor_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mrevision_actor_temp` (
  `revactor_rev` int unsigned NOT NULL,
  `revactor_actor` bigint unsigned NOT NULL,
  `revactor_timestamp` binary(14) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `revactor_page` int unsigned NOT NULL,
  PRIMARY KEY (`revactor_rev`,`revactor_actor`),
  UNIQUE KEY `revactor_rev` (`revactor_rev`),
  KEY `actor_timestamp` (`revactor_actor`,`revactor_timestamp`),
  KEY `page_actor_timestamp` (`revactor_page`,`revactor_actor`,`revactor_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mrevision_actor_temp`
--

LOCK TABLES `m2mrevision_actor_temp` WRITE;
/*!40000 ALTER TABLE `m2mrevision_actor_temp` DISABLE KEYS */;
INSERT INTO `m2mrevision_actor_temp` VALUES (1,2,_binary '20241227194233',1);
/*!40000 ALTER TABLE `m2mrevision_actor_temp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mrevision_comment_temp`
--

DROP TABLE IF EXISTS `m2mrevision_comment_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mrevision_comment_temp` (
  `revcomment_rev` int unsigned NOT NULL,
  `revcomment_comment_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`revcomment_rev`,`revcomment_comment_id`),
  UNIQUE KEY `revcomment_rev` (`revcomment_rev`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mrevision_comment_temp`
--

LOCK TABLES `m2mrevision_comment_temp` WRITE;
/*!40000 ALTER TABLE `m2mrevision_comment_temp` DISABLE KEYS */;
INSERT INTO `m2mrevision_comment_temp` VALUES (1,1);
/*!40000 ALTER TABLE `m2mrevision_comment_temp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2msearchindex`
--

DROP TABLE IF EXISTS `m2msearchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2msearchindex` (
  `si_page` int unsigned NOT NULL,
  `si_title` varchar(255) NOT NULL DEFAULT '',
  `si_text` mediumtext NOT NULL,
  UNIQUE KEY `si_page` (`si_page`),
  FULLTEXT KEY `si_title` (`si_title`),
  FULLTEXT KEY `si_text` (`si_text`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2msearchindex`
--

LOCK TABLES `m2msearchindex` WRITE;
/*!40000 ALTER TABLE `m2msearchindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2msearchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2msite_identifiers`
--

DROP TABLE IF EXISTS `m2msite_identifiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2msite_identifiers` (
  `si_type` varbinary(32) NOT NULL,
  `si_key` varbinary(32) NOT NULL,
  `si_site` int unsigned NOT NULL,
  PRIMARY KEY (`si_type`,`si_key`),
  KEY `site_ids_site` (`si_site`),
  KEY `site_ids_key` (`si_key`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2msite_identifiers`
--

LOCK TABLES `m2msite_identifiers` WRITE;
/*!40000 ALTER TABLE `m2msite_identifiers` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2msite_identifiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2msite_stats`
--

DROP TABLE IF EXISTS `m2msite_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2msite_stats` (
  `ss_row_id` int unsigned NOT NULL,
  `ss_total_edits` bigint unsigned DEFAULT NULL,
  `ss_good_articles` bigint unsigned DEFAULT NULL,
  `ss_total_pages` bigint unsigned DEFAULT NULL,
  `ss_users` bigint unsigned DEFAULT NULL,
  `ss_active_users` bigint unsigned DEFAULT NULL,
  `ss_images` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`ss_row_id`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2msite_stats`
--

LOCK TABLES `m2msite_stats` WRITE;
/*!40000 ALTER TABLE `m2msite_stats` DISABLE KEYS */;
INSERT INTO `m2msite_stats` VALUES (1,0,0,0,1,0,0);
/*!40000 ALTER TABLE `m2msite_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2msites`
--

DROP TABLE IF EXISTS `m2msites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2msites` (
  `site_id` int unsigned NOT NULL AUTO_INCREMENT,
  `site_global_key` varbinary(64) NOT NULL,
  `site_type` varbinary(32) NOT NULL,
  `site_group` varbinary(32) NOT NULL,
  `site_source` varbinary(32) NOT NULL,
  `site_language` varbinary(35) NOT NULL,
  `site_protocol` varbinary(32) NOT NULL,
  `site_domain` varbinary(255) NOT NULL,
  `site_data` blob NOT NULL,
  `site_forward` tinyint(1) NOT NULL,
  `site_config` blob NOT NULL,
  PRIMARY KEY (`site_id`),
  UNIQUE KEY `sites_global_key` (`site_global_key`),
  KEY `sites_type` (`site_type`),
  KEY `sites_group` (`site_group`),
  KEY `sites_source` (`site_source`),
  KEY `sites_language` (`site_language`),
  KEY `sites_protocol` (`site_protocol`),
  KEY `sites_domain` (`site_domain`),
  KEY `sites_forward` (`site_forward`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2msites`
--

LOCK TABLES `m2msites` WRITE;
/*!40000 ALTER TABLE `m2msites` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2msites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mslot_roles`
--

DROP TABLE IF EXISTS `m2mslot_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mslot_roles` (
  `role_id` smallint NOT NULL AUTO_INCREMENT,
  `role_name` varbinary(64) NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mslot_roles`
--

LOCK TABLES `m2mslot_roles` WRITE;
/*!40000 ALTER TABLE `m2mslot_roles` DISABLE KEYS */;
INSERT INTO `m2mslot_roles` VALUES (1,_binary 'main');
/*!40000 ALTER TABLE `m2mslot_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mslots`
--

DROP TABLE IF EXISTS `m2mslots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mslots` (
  `slot_revision_id` bigint unsigned NOT NULL,
  `slot_role_id` smallint unsigned NOT NULL,
  `slot_content_id` bigint unsigned NOT NULL,
  `slot_origin` bigint unsigned NOT NULL,
  PRIMARY KEY (`slot_revision_id`,`slot_role_id`),
  KEY `slot_revision_origin_role` (`slot_revision_id`,`slot_origin`,`slot_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mslots`
--

LOCK TABLES `m2mslots` WRITE;
/*!40000 ALTER TABLE `m2mslots` DISABLE KEYS */;
INSERT INTO `m2mslots` VALUES (1,1,1,1);
/*!40000 ALTER TABLE `m2mslots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mtemplatelinks`
--

DROP TABLE IF EXISTS `m2mtemplatelinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mtemplatelinks` (
  `tl_from` int unsigned NOT NULL DEFAULT '0',
  `tl_from_namespace` int NOT NULL DEFAULT '0',
  `tl_namespace` int NOT NULL DEFAULT '0',
  `tl_title` varbinary(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`tl_from`,`tl_namespace`,`tl_title`),
  KEY `tl_namespace` (`tl_namespace`,`tl_title`,`tl_from`),
  KEY `tl_backlinks_namespace` (`tl_from_namespace`,`tl_namespace`,`tl_title`,`tl_from`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mtemplatelinks`
--

LOCK TABLES `m2mtemplatelinks` WRITE;
/*!40000 ALTER TABLE `m2mtemplatelinks` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mtemplatelinks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mtext`
--

DROP TABLE IF EXISTS `m2mtext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mtext` (
  `old_id` int unsigned NOT NULL AUTO_INCREMENT,
  `old_text` mediumblob NOT NULL,
  `old_flags` tinyblob NOT NULL,
  PRIMARY KEY (`old_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=binary MAX_ROWS=10000000 AVG_ROW_LENGTH=10240;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mtext`
--

LOCK TABLES `m2mtext` WRITE;
/*!40000 ALTER TABLE `m2mtext` DISABLE KEYS */;
INSERT INTO `m2mtext` VALUES (1,_binary '<strong>MediaWiki s\'ha instal·lat.</strong>\n\nConsulteu la [https://meta.wikimedia.org/wiki/Help:Contents Guia d\'Usuari] per a més informació sobre com utilitzar aquest programari wiki.\n\n== Primers passos ==\n\n* [https://www.mediawiki.org/wiki/Special:MyLanguage/Manual:Configuration_settings Llista de paràmetres configurables]\n* [https://www.mediawiki.org/wiki/Special:MyLanguage/Manual:FAQ PMF del MediaWiki]\n* [https://lists.wikimedia.org/postorius/lists/mediawiki-announce.lists.wikimedia.org/ Llista de correu per a anuncis del MediaWiki]\n* [https://www.mediawiki.org/wiki/Special:MyLanguage/Localisation#Translation_resources Traducció de MediaWiki en la vostra llengua]\n* [https://www.mediawiki.org/wiki/Special:MyLanguage/Manual:Combating_spam Aprengueu com combatre la brossa que pot atacar el vostre wiki]',_binary 'utf-8');
/*!40000 ALTER TABLE `m2mtext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mupdatelog`
--

DROP TABLE IF EXISTS `m2mupdatelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mupdatelog` (
  `ul_key` varbinary(255) NOT NULL,
  `ul_value` blob,
  PRIMARY KEY (`ul_key`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mupdatelog`
--

LOCK TABLES `m2mupdatelog` WRITE;
/*!40000 ALTER TABLE `m2mupdatelog` DISABLE KEYS */;
INSERT INTO `m2mupdatelog` VALUES (_binary 'PingBack',_binary 'e3d2bb6be7033f1524e229354db0e49d'),(_binary 'Pingback-1.35.6',_binary '1735328843'),(_binary 'filearchive-fa_major_mime-patch-fa_major_mime-chemical.sql',NULL),(_binary 'image-img_major_mime-patch-img_major_mime-chemical.sql',NULL),(_binary 'oldimage-oi_major_mime-patch-oi_major_mime-chemical.sql',NULL),(_binary 'user_former_groups-ufg_group-patch-ufg_group-length-increase-255.sql',NULL),(_binary 'user_groups-ug_group-patch-ug_group-length-increase-255.sql',NULL),(_binary 'user_properties-up_property-patch-up_property.sql',NULL);
/*!40000 ALTER TABLE `m2mupdatelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2muploadstash`
--

DROP TABLE IF EXISTS `m2muploadstash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2muploadstash` (
  `us_id` int unsigned NOT NULL AUTO_INCREMENT,
  `us_user` int unsigned NOT NULL,
  `us_key` varbinary(255) NOT NULL,
  `us_orig_path` varbinary(255) NOT NULL,
  `us_path` varbinary(255) NOT NULL,
  `us_source_type` varbinary(50) DEFAULT NULL,
  `us_timestamp` varbinary(14) NOT NULL,
  `us_status` varbinary(50) NOT NULL,
  `us_chunk_inx` int unsigned DEFAULT NULL,
  `us_props` blob,
  `us_size` int unsigned NOT NULL,
  `us_sha1` varbinary(31) NOT NULL,
  `us_mime` varbinary(255) DEFAULT NULL,
  `us_media_type` enum('UNKNOWN','BITMAP','DRAWING','AUDIO','VIDEO','MULTIMEDIA','OFFICE','TEXT','EXECUTABLE','ARCHIVE','3D') DEFAULT NULL,
  `us_image_width` int unsigned DEFAULT NULL,
  `us_image_height` int unsigned DEFAULT NULL,
  `us_image_bits` smallint unsigned DEFAULT NULL,
  PRIMARY KEY (`us_id`),
  UNIQUE KEY `us_key` (`us_key`),
  KEY `us_user` (`us_user`),
  KEY `us_timestamp` (`us_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2muploadstash`
--

LOCK TABLES `m2muploadstash` WRITE;
/*!40000 ALTER TABLE `m2muploadstash` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2muploadstash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2muser`
--

DROP TABLE IF EXISTS `m2muser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2muser` (
  `user_id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varbinary(255) NOT NULL DEFAULT '',
  `user_real_name` varbinary(255) NOT NULL DEFAULT '',
  `user_password` tinyblob NOT NULL,
  `user_newpassword` tinyblob NOT NULL,
  `user_newpass_time` binary(14) DEFAULT NULL,
  `user_email` tinyblob NOT NULL,
  `user_touched` binary(14) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `user_token` binary(32) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `user_email_authenticated` binary(14) DEFAULT NULL,
  `user_email_token` binary(32) DEFAULT NULL,
  `user_email_token_expires` binary(14) DEFAULT NULL,
  `user_registration` binary(14) DEFAULT NULL,
  `user_editcount` int DEFAULT NULL,
  `user_password_expires` varbinary(14) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`),
  KEY `user_email_token` (`user_email_token`),
  KEY `user_email` (`user_email`(50))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2muser`
--

LOCK TABLES `m2muser` WRITE;
/*!40000 ALTER TABLE `m2muser` DISABLE KEYS */;
INSERT INTO `m2muser` VALUES (1,_binary 'Sergio','',_binary ':pbkdf2:sha512:30000:64:/dr5T0UWO6v1yuLU0A64yA==:MQorrEIaWCukTWIsl0o9skSSKSos9gDHXCkc/ClBC27EV9h23vpWvmxDdneFfTFtHWJxdnoZaFh7KNG5LFoDvg==','',NULL,_binary 'sesantam@uoc.edu',_binary '20241227194234',_binary 'e35b1edacd1bc40e7b2ede762b7d8f6b',NULL,NULL,NULL,_binary '20241227194233',0,NULL),(2,_binary 'MediaWiki default','','','',NULL,'',_binary '20241227194233',_binary '*** INVALID ***\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',NULL,NULL,NULL,_binary '20241227194233',0,NULL);
/*!40000 ALTER TABLE `m2muser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2muser_former_groups`
--

DROP TABLE IF EXISTS `m2muser_former_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2muser_former_groups` (
  `ufg_user` int unsigned NOT NULL DEFAULT '0',
  `ufg_group` varbinary(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`ufg_user`,`ufg_group`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2muser_former_groups`
--

LOCK TABLES `m2muser_former_groups` WRITE;
/*!40000 ALTER TABLE `m2muser_former_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2muser_former_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2muser_groups`
--

DROP TABLE IF EXISTS `m2muser_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2muser_groups` (
  `ug_user` int unsigned NOT NULL DEFAULT '0',
  `ug_group` varbinary(255) NOT NULL DEFAULT '',
  `ug_expiry` varbinary(14) DEFAULT NULL,
  PRIMARY KEY (`ug_user`,`ug_group`),
  KEY `ug_group` (`ug_group`),
  KEY `ug_expiry` (`ug_expiry`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2muser_groups`
--

LOCK TABLES `m2muser_groups` WRITE;
/*!40000 ALTER TABLE `m2muser_groups` DISABLE KEYS */;
INSERT INTO `m2muser_groups` VALUES (1,_binary 'bureaucrat',NULL),(1,_binary 'interface-admin',NULL),(1,_binary 'sysop',NULL);
/*!40000 ALTER TABLE `m2muser_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2muser_newtalk`
--

DROP TABLE IF EXISTS `m2muser_newtalk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2muser_newtalk` (
  `user_id` int unsigned NOT NULL DEFAULT '0',
  `user_ip` varbinary(40) NOT NULL DEFAULT '',
  `user_last_timestamp` varbinary(14) DEFAULT NULL,
  KEY `un_user_id` (`user_id`),
  KEY `un_user_ip` (`user_ip`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2muser_newtalk`
--

LOCK TABLES `m2muser_newtalk` WRITE;
/*!40000 ALTER TABLE `m2muser_newtalk` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2muser_newtalk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2muser_properties`
--

DROP TABLE IF EXISTS `m2muser_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2muser_properties` (
  `up_user` int unsigned NOT NULL,
  `up_property` varbinary(255) NOT NULL,
  `up_value` blob,
  PRIMARY KEY (`up_user`,`up_property`),
  KEY `user_properties_property` (`up_property`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2muser_properties`
--

LOCK TABLES `m2muser_properties` WRITE;
/*!40000 ALTER TABLE `m2muser_properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2muser_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mwatchlist`
--

DROP TABLE IF EXISTS `m2mwatchlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mwatchlist` (
  `wl_id` int unsigned NOT NULL AUTO_INCREMENT,
  `wl_user` int unsigned NOT NULL,
  `wl_namespace` int NOT NULL DEFAULT '0',
  `wl_title` varbinary(255) NOT NULL DEFAULT '',
  `wl_notificationtimestamp` varbinary(14) DEFAULT NULL,
  PRIMARY KEY (`wl_id`),
  UNIQUE KEY `wl_user` (`wl_user`,`wl_namespace`,`wl_title`),
  KEY `namespace_title` (`wl_namespace`,`wl_title`),
  KEY `wl_user_notificationtimestamp` (`wl_user`,`wl_notificationtimestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mwatchlist`
--

LOCK TABLES `m2mwatchlist` WRITE;
/*!40000 ALTER TABLE `m2mwatchlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mwatchlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m2mwatchlist_expiry`
--

DROP TABLE IF EXISTS `m2mwatchlist_expiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `m2mwatchlist_expiry` (
  `we_item` int unsigned NOT NULL,
  `we_expiry` binary(14) NOT NULL,
  PRIMARY KEY (`we_item`),
  KEY `we_expiry` (`we_expiry`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m2mwatchlist_expiry`
--

LOCK TABLES `m2mwatchlist_expiry` WRITE;
/*!40000 ALTER TABLE `m2mwatchlist_expiry` DISABLE KEYS */;
/*!40000 ALTER TABLE `m2mwatchlist_expiry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'wikidb'
--

--
-- Dumping routines for database 'wikidb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-04 20:27:39
